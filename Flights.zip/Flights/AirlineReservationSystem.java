/**C234098702
 * Conor McCarthy
 */


import java.util.ArrayList;
import java.util.Scanner;

public class AirlineReservationSystem {
    private ArrayList<Flight> flights;
    private ArrayList<Passenger> passengers;
    private Scanner scanner;

    public AirlineReservationSystem() {
        flights = new ArrayList<>();
        passengers = new ArrayList<>();
        scanner = new Scanner(System.in);
    }

    public void run() {
        createFlights();
        int choice;
    }
  
    private void createFlights() {
        for (int i = 0; i < 5; i++) {
            System.out.println("Enter details for Flight " + (i + 1) + ":");
            System.out.print("Flight Number (EI###): ");
            String flightNumber = scanner.nextLine();
            if (!flightNumber.matches("EI\\d{3}")) {
                System.out.println("Invalid flight number format. Flight not added.");
                continue;
            }
            System.out.print("Day of the week: ");
            String dayOfWeek = scanner.nextLine();
            System.out.print("Destination: ");
            String destination = scanner.nextLine();
            
            
        }
    }

    private void displayMenu() {
        System.out.println("\n===== Menu =====");
        System.out.println("1. Make a Booking");
        System.out.println("2. Cancel a Booking");
        System.out.println("3. Display Full Flight Schedule");
        System.out.println("4. Display Passengers with Flight Bookings");
        System.out.println("5. Menu option for personal flight action");
        System.out.println("6. Menu option for personal passenger action");
        System.out.println("7. Exit System");
    }

    private int getValidMenuChoice() {
        int choice;
        do {
            System.out.print("Enter your choice: ");
            while (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next();
            }
            choice = scanner.nextInt();
        } while (choice < 1 || choice > 7);
        scanner.nextLine();
        return choice;
    }

    private void makeBooking() {
        
    }

    private void cancelBooking() {
       
    }

    private void displayFullFlightSchedule() {
        
    }

    private void displayPassengersWithFlightBookings() {
        
    }

    public static void main(String[] args) {
        AirlineReservationSystem system = new AirlineReservationSystem();
        system.run();
    }
}

class Flight1 {
    private String flightNumber;
    private String dayOfWeek;
    private String destination;
    private int seatsBooked;
    private int passportNumber;

    public Flight1(String flightNumber, String dayOfWeek, String destination) {
        this.flightNumber = flightNumber;
        this.dayOfWeek = dayOfWeek;
        this.destination = destination;
    }

    public int getFreeSeats() {
        return 10 - seatsBooked;
    }

    public void bookSeat() {
        seatsBooked++;
    }

    public void cancelSeat() {
        seatsBooked--;
    }

    public String toString() {
        return "Flight: " + flightNumber + " | Day: " + dayOfWeek + " | Destination: " + destination +
                " | Seats Booked: " + seatsBooked;
    }
}

class Passenger1 {
    private String name;
    private String address;
    private String emailAddress;
    private Flight flightBooking;

    public Passenger1(String name, String address, String emailAddress) {
        this.name = name;
        this.address = address;
        this.emailAddress = emailAddress;
    }

    public boolean hasFlightBooking() {
        return flightBooking != null;
         
    }

    
}
