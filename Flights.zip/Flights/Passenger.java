
public class Passenger
{
    private int x;
    public Passenger()
    {
        x = 0;
    }

    public int sampleMethod(int y)
    {
        return x + y;
    }
}
