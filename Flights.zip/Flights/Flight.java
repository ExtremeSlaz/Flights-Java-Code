public class Flight
{
    private int x;
    public Flight()
    {
        x = 0;
    }

    public int sampleMethod(int y)
    {
        return x + y;
    }
}
